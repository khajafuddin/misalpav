echo -e "Install Address Book on your system [Y/N]: \c"
read CHOICE
case $CHOICE in
     Y|y)
       DIR_PATH=`pwd`
       touch /bin/addressbook
       echo "cd $DIR_PATH" > /bin/addressbook
       echo "./main.sh" >> /bin/addressbook
       chmod a+x /bin/addressbook
       echo "Address Book installed successfully!"
       ;;
     N|n)
       echo "Installation aborted by the user."
       ;;
     *)
       echo "Invalid Entry!"
       echo "Run 0-install.sh again to install Address Book."
       ;;
esac
     
