echo -e "Uninstall Address Book from your system [Y/N]: \c"
read CHOICE
case $CHOICE in
     Y|y)
       rm -f /bin/addressbook
       echo "Address Book uninstalled successfully!"
       ;;
     N|n)
       echo "Uninstallation aborted by the user."
       ;;
     *)
       echo "Invalid Entry!"
       echo "Run uninstall.sh again to uninstall Address Book."
       ;;
esac
     
