clear
add_fn_1()
{
echo -e "[\033[32mA\033[0m] Add contact"
echo -e "[\033[32mN\033[0m] Enter new contact"
echo -e "[\033[32mR\033[0m] Return to main menu"
echo -e "[\033[32mQ\033[0m] Quit"
echo
echo -e "Enter your choice: \c"
read CHOICE
case $CHOICE in
     A|a) echo "$NAME,$LOCATION,$BATCH,$TEL_NO,$MOBILE" >> address.db
	  sort address.db > .address.tmp
	  cp -f .address.tmp address.db
          echo
          echo -e "\033[32mContact added successfully!\033[0m" ;;
     N|n) . add.sh ;;
     R|r) . main.sh ;;
     Q|q) clear
          exit ;;
       *) echo
          echo -e "\033[31mInvalid entry!\033[0m"
          echo
          add_fn_1 ;;
esac
}
add_fn_2()
{
echo -e "[\033[32mN\033[0m] Enter new contact"
echo -e "[\033[32mR\033[0m] Return to the main menu"
echo -e "[\033[32mQ\033[0m] Quit"
echo
echo -e "Enter your choice: \c"
read CHOICE
case $CHOICE in
     N|n) . add.sh ;;
     R|r) . main.sh ;;
     Q|q) clear
          exit ;;
       *) echo
          echo -e "\033[31mInvalid entry!\033[0m"
          echo
          add_fn_2 ;;
esac
}
echo
echo Enter contact details,
echo
echo -e "\tName       : \c"
read NAME
if [ -z "$NAME" ]; then
echo
echo -e "\033[31mError!\033[0m"
echo "Name field cannot be empty."
echo
add_fn_2
fi
echo -e "\tLocation   : \c"
read LOCATION
if [ -z "$LOCATION" ]; then
LOCATION=--
fi
echo -e "\tBatch Name : \c"
read BATCH
if [ -z "$BATCH" ]; then
BATCH=--
fi
echo -e "\tTel. No.   : \c"
read TEL_NO
if [ -z "$TEL_NO" ]; then
TEL_NO=--
fi
echo -e "\tMobile     : \c"
read MOBILE
if [ -z "$MOBILE" ]; then
MOBILE=--
fi
echo
add_fn_1
echo
add_fn_2
