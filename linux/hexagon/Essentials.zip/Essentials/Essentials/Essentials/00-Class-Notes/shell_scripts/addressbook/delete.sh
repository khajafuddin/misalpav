clear
delete_fn_1()
{
echo -e "[\033[32mA\033[0m] Delete another contact"
echo -e "[\033[32mR\033[0m] Return to the main menu"
echo -e "[\033[32mQ\033[0m] Quit"
echo
echo -e "Enter your choice: \c"
read CHOICE
case $CHOICE in
     A|a) . delete.sh ;;
     R|r) . main.sh ;;
     Q|q) clear
          exit ;;
       *) echo
          echo -e "\033[31mInvalid entry!\033[0m"
          echo
          delete_fn_1 ;;
esac
}
delete_fn_2()
{
echo -e "[\033[32mD\033[0m] Delete the above contact/s"
echo -e "[\033[32mA\033[0m] Delete another contact"
echo -e "[\033[32mR\033[0m] Return to the main menu"
echo -e "[\033[32mQ\033[0m] Quit"
echo
echo -e "Enter your choice: \c"
read CHOICE
case $CHOICE in
     D|d) echo
          echo -e "Are you sure? [Y/N]: \c"
          read CHOICE
          case $CHOICE in
               Y|y) while [ `grep -i "$WORD" address.db | wc -l` -gt 0 ]
                      do
                        sed -i "/`grep -i "$WORD" address.db | head -n 1`/d" address.db
                      done
		    echo
                    echo -e "\033[32mContact/s deleted successfully!\033[0m" ;;
               N|n) echo
                    delete_fn_1 ;;
                 *) echo
                    echo -e "\033[31mInvalid entry!\033[0m"
                    echo
                    delete_fn_2 ;;
          esac ;;
     A|a) . delete.sh ;;
     R|r) . main.sh ;;
     Q|q) clear
          exit ;;
       *) echo
          echo -e "\033[31mInvalid entry!\033[0m"
          echo
          delete_fn_2 ;;
esac
}
delete_fn_3()
{
echo -e "[\033[32mD\033[0m] Delete all the contacts"
echo -e "[\033[32mA\033[0m] Delete another contact"
echo -e "[\033[32mR\033[0m] Return to the main menu"
echo -e "[\033[32mQ\033[0m] Quit"
echo
echo -e "Enter your choice: \c"
read CHOICE
case $CHOICE in
     D|d) echo
          delete_fn_4 ;;
     A|a) . delete.sh ;;
     R|r) . main.sh ;;
     Q|q) clear
          exit ;;
       *) echo
          echo -e "\033[31mInvalid entry!\033[0m"
          echo
          delete_fn_3 ;;
esac
}
delete_fn_4()
{
echo -e "\033[31mYou are about to\033[0m \033[5mdelete all contacts\033[0m \033[31min the database!\033[0m"
echo
echo -e "Are you sure? [Y/N]: \c"
read CHOICE
case $CHOICE in
     Y|y) > address.db
	  echo
          echo -e "\033[32mAll contacts deleted!\033[0m" ;;
     N|n) echo
          delete_fn_1 ;;
       *) echo
          echo -e "\033[31mInvalid entry!\033[0m"
          echo
          delete_fn_4 ;;
esac
}
delete_fn_5()
{
echo -e "[\033[32mD\033[0m] Delete the above contact"
echo -e "[\033[32mA\033[0m] Delete another contact"
echo -e "[\033[32mR\033[0m] Return to the main menu"
echo -e "[\033[32mQ\033[0m] Quit"
echo
echo -e "Enter your choice: \c"
read CHOICE
case $CHOICE in
     D|d) echo
          echo -e "Are you sure? [Y/N]: \c"
          read CHOICE
          case $CHOICE in
               Y|y) sed -i "$WORD"d address.db
		    echo
                    echo -e "\033[32mContact deleted successfully!\033[0m" ;;
               N|n) echo
                    delete_fn_1 ;;
                 *) echo
                    echo -e "\033[31mInvalid entry!\033[0m"
                    echo
                    delete_fn_5 ;;
          esac ;;
     A|a) . delete.sh ;;
     R|r) . main.sh ;;
     Q|q) clear
          exit ;;
       *) echo
          echo -e "\033[31mInvalid entry!\033[0m"
          echo
          delete_fn_5 ;;
esac
}
echo
echo "Enter a Word or Number to search for the Contact,"
echo -e "OR type \".\" to delete all contacts: \c"
read WORD
if [ -z "$WORD" ]; then
  echo
  echo -e "\033[31mInvalid entry!\033[0m"
  echo
  delete_fn_1
elif [ -z `cat address.db | wc -l` ]; then
  echo
  echo -e "\033[31mAddress Book is empty!\033[0m"
  echo
  delete_fn_1
elif [ "$WORD" = . ]; then
  echo
  delete_fn_3 
  echo
  delete_fn_1
elif [ "$WORD" -eq 0 -o 1 -o 2 -o 3 -o 4 -o 5 -o 6 -o 7 -o 8 -o 9 2> /dev/null ]; then
  if [ `cat -n address.db | cut -f1 | grep "$WORD" | wc -l` -gt 0 ]; then
    echo
    tput cup 4
    echo -e "\033[33mNo.   Name                Location              Batch Name Tel. No.   Mobile  \033[0m"
    echo -e "\033[33m====  ==================  ====================  ========== ========== ==========\033[0m"
    tput cup 6 1
    echo "$WORD"
    tput cup 6 6
    echo "`sed -n "$WORD"p address.db | cut -f2 | cut -d, -f1`"
    tput cup 6 26
    echo "`sed -n "$WORD"p address.db | cut -d, -f2`"
    tput cup 6 48
    echo "`sed -n "$WORD"p address.db | cut -d, -f3`"
    tput cup 6 59
    echo "`sed -n "$WORD"p address.db | cut -d, -f4`"
    tput cup 6 70
    echo "`sed -n "$WORD"p address.db | cut -d, -f5`"
    echo -e "\033[33m====  ==================  ====================  ========== ========== ==========\033[0m"
    echo
    delete_fn_5
    echo
    delete_fn_1
  else
    echo
    echo -e "\033[31mNo match found!\033[0m"
    echo "The serial number entered does not exist."
    echo
    delete_fn_1
  fi
elif [ `grep -i "$WORD" address.db | wc -l` -gt 0 ]; then
  echo
  FIRST=1
  LAST=`grep -i "$WORD" address.db | wc -l`
  ROW=6
  cat -n address.db|grep -i "$WORD" > .address.tmp
  tput cup 4
  echo -e "\033[33mNo.   Name                Location              Batch Name Tel. No.   Mobile  \033[0m"
  echo -e "\033[33m====  ==================  ====================  ========== ========== ==========\033[0m"
  while [ $FIRST -le $LAST ]
    do
      tput cup $ROW 1
      echo "`head -n 1 .address.tmp | cut -f1 | sed "s/ //g"`"
      tput cup $ROW 6
      echo "`head -n 1 .address.tmp | cut -f2 | cut -d, -f1`"
      tput cup $ROW 26
      echo "`head -n 1 .address.tmp | cut -d, -f2`"
      tput cup $ROW 48
      echo "`head -n 1 .address.tmp | cut -d, -f3`"
      tput cup $ROW 59
      echo "`head -n 1 .address.tmp | cut -d, -f4`"
      tput cup $ROW 70
      echo "`head -n 1 .address.tmp | cut -d, -f5`"
      sed -i "/`head -n 1 .address.tmp`/d" .address.tmp
      FIRST=`expr $FIRST + 1`
      ROW=`expr $ROW + 1`
      if [ $ROW -eq 22 ]; then
    echo -e "\033[33m====  ==================  ====================  ========== ========== ==========\033[0m"
      echo
      echo -e "Press any key to continue...\c"
      read -n 1
      clear
      tput cup 1
    echo -e "\033[33mNo.   Name                Location              Batch Name Tel. No.   Mobile  \033[0m"
    echo -e "\033[33m====  ==================  ====================  ========== ========== ==========\033[0m"
      ROW=3
      fi
    done
  echo -e "\033[33m====  ==================  ====================  ========== ========== ==========\033[0m"
  echo
  delete_fn_2
  echo
  delete_fn_1
else
  echo
  echo -e "\033[31mNo match found!\033[0m"
  echo "Either the spelling is incorrect or the contact does not exist."
  echo
  delete_fn_1
fi
