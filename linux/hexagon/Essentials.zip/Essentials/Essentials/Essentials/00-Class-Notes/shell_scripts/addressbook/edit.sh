clear
edit_fn_1()
{
echo -e "[\033[32mA\033[0m] Edit another contact"
echo -e "[\033[32mR\033[0m] Return to the main menu"
echo -e "[\033[32mQ\033[0m] Quit"
echo
echo -e "Enter your choice: \c"
read CHOICE
case $CHOICE in
     A|a) . edit.sh ;;
     R|r) . main.sh ;;
     Q|q) clear
          exit ;;
       *) echo
          echo -e "\033[31mInvalid entry!\033[0m"
          echo
          edit_fn_1 ;;
esac
}
edit_fn_2()
{
echo -e "[\033[32mE\033[0m] Edit the above contact"
echo -e "[\033[32mA\033[0m] Edit another contact"
echo -e "[\033[32mR\033[0m] Return to the main menu"
echo -e "[\033[32mQ\033[0m] Quit"
echo
echo -e "Enter your choice: \c"
read CHOICE
case $CHOICE in
     E|e) sed -i "$WORD"c"$NAME,$LOCATION,$BATCH,$TEL_NO,$MOBILE" address.db
	  echo
	  echo -e "\033[32mContact edited successfully!\033[0m" ;;
     A|a) . edit.sh ;;
     R|r) . main.sh ;;
     Q|q) clear
          exit ;;
       *) echo
          echo -e "\033[31mInvalid entry!\033[0m"
          echo
          edit_fn_2 ;;
esac
}
echo
echo -e "Enter a Word or Number to search for the Contact to be edited: \c"
read WORD
if [ -z "$WORD" ]
then
echo
echo -e "\033[31mInvalid entry!\033[0m"
echo
edit_fn_1
elif [ `cat address.db | wc -l` -eq 0 ]
then
echo
echo -e "\033[31mAddress Book is empty!\033[0m"
echo
edit_fn_1
elif [ "$WORD" -eq 0 -o 1 -o 2 -o 3 -o 4 -o 5 -o 6 -o 7 -o 8 -o 9 2> /dev/null ]
then
if [ `cat -n address.db | cut -f1 | grep "$WORD" | sed "s/ //g" | wc -l` -eq 1 ]
then
echo
tput cup 3
echo -e "\033[33mNo.   Name                Location              Batch Name Tel. No.   Mobile  \033[0m"
echo -e "\033[33m====  ==================  ====================  ========== ========== ==========\033[0m"
tput cup 5 1
echo "$WORD"
tput cup 5 6
echo "`sed -n "$WORD"p address.db | cut -d, -f1`"
tput cup 5 26
echo "`sed -n "$WORD"p address.db | cut -d, -f2`"
tput cup 5 48
echo "`sed -n "$WORD"p address.db | cut -d, -f3`"
tput cup 5 59
echo "`sed -n "$WORD"p address.db | cut -d, -f4`"
tput cup 5 70
echo "`sed -n "$WORD"p address.db | cut -d, -f5`"
echo -e "\033[33m====  ==================  ====================  ========== ========== ==========\033[0m"
echo
echo Note:  
echo ====
echo "      1. To change value type new value and press \"ENTER\""
echo "      2. To retain value press only \"ENTER\""
echo "      3. To delete value type \"X\" and press \"ENTER\""
echo
echo -e "\tName       : \c"
read NAME
if [ -z "$NAME" ]; then
NAME=`sed -n "$WORD"p address.db | cut -d, -f1`
elif [ "$NAME" = "X" -o "$NAME" = "x" ]; then
echo
echo -e "\033[31mError!\033[0m"
echo "Name field cannot be empty."
echo
edit_fn_2
fi
echo -e "\tLocation   : \c"
read LOCATION
if [ -z "$LOCATION" ]; then
LOCATION=`sed -n "$WORD"p address.db | cut -d, -f2`
elif [ "$LOCATION" = "X" -o "$LOCATION" = "x" ]; then
LOCATION=--
fi
echo -e "\tBatch Name : \c"
read BATCH
if [ -z "$BATCH" ]; then
BATCH=`sed -n "$WORD"p address.db | cut -d, -f3`
elif [ "$BATCH" = "X" -o "$BATCH" = "x" ]; then
BATCH=--
fi
echo -e "\tTel. No.   : \c"
read TEL_NO
if [ -z "$TEL_NO" ]; then
TEL_NO=`sed -n "$WORD"p address.db | cut -d, -f4`
elif [ "$TEL_NO" = "X" -o "$TEL_NO" = "x" ]; then
TEL_NO=--
fi
echo -e "\tMob. No.   : \c"
read MOBILE
if [ -z "$MOBILE" ]; then
MOBILE=`sed -n "$WORD"p address.db | cut -d, -f5`
elif [ "$MOBILE" = "X" -o "$MOBILE" = "x" ]; then
MOBILE=--
fi
echo
edit_fn_2
echo
edit_fn_1
else
echo
echo -e "\033[31mNo match found!\033[0m"
echo "The serial number entered does not exist."
echo
edit_fn_1
fi
elif [ `grep -i "$WORD" address.db | wc -l` -eq 1 ]
then
echo
tput cup 3
echo -e "\033[33mNo.   Name                Location              Batch Name Tel. No.   Mobile  \033[0m"
echo -e "\033[33m====  ==================  ====================  ========== ========== ==========\033[0m"
tput cup 5 1
echo "`cat -n address.db | grep -i "$WORD" | cut -f1 | sed "s/ //g"`"
tput cup 5 6
echo "`grep -i "$WORD" address.db | cut -d, -f1`"
tput cup 5 26
echo "`grep -i "$WORD" address.db | cut -d, -f2`"
tput cup 5 48
echo "`grep -i "$WORD" address.db | cut -d, -f3`"
tput cup 5 59
echo "`grep -i "$WORD" address.db | cut -d, -f4`"
tput cup 5 70
echo "`grep -i "$WORD" address.db | cut -d, -f5`"
echo -e "\033[33m====  ==================  ====================  ========== ========== ==========\033[0m"
echo
echo Note:  
echo ====
echo "      1. To change value type new value and press \"ENTER\""
echo "      2. To retain value press only \"ENTER\""
echo "      3. To delete value type \"X\" and press \"ENTER\""
echo
WORD=`cat -n address.db | grep -i "$WORD" | cut -f1 | sed "s/ //g"`
echo -e "\tName       : \c"
read NAME
if [ -z "$NAME" ]; then
NAME=`sed -n "$WORD"p address.db | cut -d, -f1`
elif [ "$NAME" = "X" -o "$NAME" = "x" ]; then
echo
echo -e "\033[31mError!\033[0m"
echo "Name field cannot be empty."
echo
edit_fn_2
fi
echo -e "\tLocation   : \c"
read LOCATION
if [ -z "$LOCATION" ]; then
LOCATION=`sed -n "$WORD"p address.db | cut -d, -f2`
elif [ "$LOCATION" = "X" -o "$LOCATION" = "x" ]; then
LOCATION=--
fi
echo -e "\tBatch Name : \c"
read BATCH
if [ -z "$BATCH" ]; then
BATCH=`sed -n "$WORD"p address.db | cut -d, -f3`
elif [ "$BATCH" = "X" -o "$BATCH" = "x" ]; then
BATCH=--
fi
echo -e "\tTel. No.   : \c"
read TEL_NO
if [ -z "$TEL_NO" ]; then
TEL_NO=`sed -n "$WORD"p address.db | cut -d, -f4`
elif [ "$TEL_NO" = "X" -o "$TEL_NO" = "x" ]; then
TEL_NO=--
fi
echo -e "\tMob. No.   : \c"
read MOBILE
if [ -z "$MOBILE" ]; then
MOBILE=`sed -n "$WORD"p address.db | cut -d, -f5`
elif [ "$MOBILE" = "X" -o "$MOBILE" = "x" ]; then
MOBILE=--
fi
echo
edit_fn_2
echo
edit_fn_1
elif [ `grep -i "$WORD" address.db | wc -l` -gt 1 ]
then
echo
FIRST=1
LAST=`grep -i "$WORD" address.db | wc -l`
ROW=5
cat -n address.db | grep -i "$WORD" > .address.tmp
tput cup 3
echo -e "\033[33mNo.   Name                Location              Batch Name Tel. No.   Mobile  \033[0m"
echo -e "\033[33m====  ==================  ====================  ========== ========== ==========\033[0m"
while [ $FIRST -le $LAST ]
do
  tput cup $ROW 1
  echo "`head -n 1 .address.tmp | cut -f1 | sed "s/ //g"`"
  tput cup $ROW 6
  echo "`head -n 1 .address.tmp | cut -f2 | cut -d, -f1`"
  tput cup $ROW 26
  echo "`head -n 1 .address.tmp | cut -d, -f2`"
  tput cup $ROW 48
  echo "`head -n 1 .address.tmp | cut -d, -f3`"
  tput cup $ROW 59
  echo "`head -n 1 .address.tmp | cut -d, -f4`"
  tput cup $ROW 70
  echo "`head -n 1 .address.tmp | cut -d, -f5`"
  sed -i "/`head -n 1 .address.tmp`/d" .address.tmp
  FIRST=`expr $FIRST + 1`
  ROW=`expr $ROW + 1`
      if [ $ROW -eq 22 ]; then
    echo -e "\033[33m====  ==================  ====================  ========== ========== ==========\033[0m"
      echo
      echo -e "Press any key to continue...\c"
      read -n 1
      clear
      tput cup 1
    echo -e "\033[33mNo.   Name                Location              Batch Name Tel. No.   Mobile  \033[0m"
    echo -e "\033[33m====  ==================  ====================  ========== ========== ==========\033[0m"
      ROW=3
      fi
done
echo -e "\033[33m====  ==================  ====================  ========== ========== ==========\033[0m"
echo
echo -e "\033[31mError!\033[0m"
echo Found more than 1 contact. Only 1 can be edited at a time.
echo Enter a specific contact name or number to be edited.
echo
edit_fn_1
else
echo
echo -e "\033[31mNo match found!\033[0m"
echo "Either the spelling is incorrect or the contact does not exist."
echo
edit_fn_1
fi
