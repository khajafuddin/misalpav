clear
tput cup 0 56
echo Written by,
tput cup 1 56
echo Ansari M. Saeed
tput cup 2 56
echo ansarimuzaffar@yahoo.com
echo
echo
echo -e "\t\t\t\t \033[44mADDRESS BOOK\033[0m"
echo -e "\t\t\t\t \033[34m************\033[0m"
tput cup 9 30
echo -e "[\033[32mA\033[0m] Add Contact"
tput cup 10 30
echo -e "[\033[32mD\033[0m] Delete Contact"
tput cup 11 30
echo -e "[\033[32mE\033[0m] Edit Contact"
tput cup 12 30
echo -e "[\033[32mS\033[0m] Search Contact"
tput cup 13 30
echo -e "[\033[32mB\033[0m] Backup"
tput cup 14 30
echo -e "[\033[32mR\033[0m] Restore"
tput cup 15 30
echo -e "[\033[32mQ\033[0m] Quit"
tput cup 17 28
echo -e "\033[31mAddress file not found!\033[0m"
tput cup 19 20
echo -e "Create another empty Address file? [Y/N]: \c"
read CHOICE
case $CHOICE in
     Y|y) touch address.db
          . main.sh ;;
     N|n) . main.sh ;;
       *) . error01.sh ;;
esac
