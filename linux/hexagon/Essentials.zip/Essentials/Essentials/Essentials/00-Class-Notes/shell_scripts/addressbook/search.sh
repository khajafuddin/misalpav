clear
search_fn_1()
{
echo -e "[\033[32mS\033[0m] Search another contact"
echo -e "[\033[32mR\033[0m] Return to the main menu"
echo -e "[\033[32mQ\033[0m] Quit"
echo
echo -e "Enter your choice: \c"
read CHOICE
case $CHOICE in
   S|s) . search.sh ;;
   R|r) . main.sh ;;
   Q|q) clear
        exit ;;
     *) echo
        echo -e "\033[31mInvalid entry!\033[0m"
        echo
        search_fn_1 ;;
esac
}
echo
echo "Enter a Word to search for the Contact,"
echo -e "OR type \".\" to list all contacts: \c"
read WORD
  if [ -z "$WORD" ]
    then
    echo
    echo -e "\033[31mInvalid entry!\033[0m"
    echo
    search_fn_1
    elif [ `cat address.db | wc -l` -eq 0 ]
    then
    echo
    echo -e "\033[31mAddress Book is empty!\033[0m"
    echo
    search_fn_1
    elif [ "$WORD" = . ]
    then
    echo
    FIRST=1
    LAST=`cat address.db | wc -l`
    ROW=6
    cat -n address.db > .address.tmp
    tput cup 4
    echo -e "\033[33mNo.   Name                Location              Batch Name Tel. No.   Mobile  \033[0m"
    echo -e "\033[33m====  ==================  ====================  ========== ========== ==========\033[0m"
    while [ $FIRST -le $LAST ]
    do
      tput cup $ROW 1
      echo "`head -n 1 .address.tmp | cut -f1 | sed "s/ //g"`"
      tput cup $ROW 6
      echo "`head -n 1 .address.tmp | cut -f2 | cut -d, -f1`"
      tput cup $ROW 26
      echo "`head -n 1 .address.tmp | cut -d, -f2`"
      tput cup $ROW 48
      echo "`head -n 1 .address.tmp | cut -d, -f3`"
      tput cup $ROW 59
      echo "`head -n 1 .address.tmp | cut -d, -f4`"
      tput cup $ROW 70
      echo "`head -n 1 .address.tmp | cut -d, -f5`"
      sed -i "/`cat .address.tmp | head -n 1`/d" .address.tmp
      FIRST=`expr $FIRST + 1`
      ROW=`expr $ROW + 1`
      if [ $ROW -eq 22 ]; then
    echo -e "\033[33m====  ==================  ====================  ========== ========== ==========\033[0m"
      echo
      echo -e "Press any key to continue...\c"
      read -n 1
      clear
      tput cup 1
    echo -e "\033[33mNo.   Name                Location              Batch Name Tel. No.   Mobile  \033[0m"
    echo -e "\033[33m====  ==================  ====================  ========== ========== ==========\033[0m"
      ROW=3
      fi
    done
    echo -e "\033[33m====  ==================  ====================  ========== ========== ==========\033[0m"
    echo
    search_fn_1
    elif [ `grep -i "$WORD" address.db | wc -l` -gt 0 ]
    then
    echo
    FIRST=1
    LAST=`grep -i "$WORD" address.db | wc -l`
    ROW=6
    cat -n address.db | grep -i "$WORD" > .address.tmp
    tput cup 4
    echo -e "\033[33mNo.   Name                Location              Batch Name Tel. No.   Mobile  \033[0m"
    echo -e "\033[33m====  ==================  ====================  ========== ========== ==========\033[0m"
    while [ $FIRST -le $LAST ]
    do
      tput cup $ROW 1
      echo "`head -n 1 .address.tmp | cut -f1 | sed "s/ //g"`"
      tput cup $ROW 6
      echo "`head -n 1 .address.tmp | cut -f2 | cut -d, -f1`"
      tput cup $ROW 26
      echo "`head -n 1 .address.tmp | cut -d, -f2`"
      tput cup $ROW 48
      echo "`head -n 1 .address.tmp | cut -d, -f3`"
      tput cup $ROW 59
      echo "`head -n 1 .address.tmp | cut -d, -f4`"
      tput cup $ROW 70
      echo "`head -n 1 .address.tmp | cut -d, -f5`"
      sed -i "/`cat .address.tmp | head -n 1`/d" .address.tmp
      FIRST=`expr $FIRST + 1`
      ROW=`expr $ROW + 1`
      if [ $ROW -eq 22 ]; then
    echo -e "\033[33m====  ==================  ====================  ========== ========== ==========\033[0m"
      echo
      echo -e "Press any key to continue...\c"
      read -n 1
      clear
      tput cup 1
    echo -e "\033[33mNo.   Name                Location              Batch Name Tel. No.   Mobile  \033[0m"
    echo -e "\033[33m====  ==================  ====================  ========== ========== ==========\033[0m"
      ROW=3
      fi
    done
    echo -e "\033[33m====  ==================  ====================  ========== ========== ==========\033[0m"
    echo
    search_fn_1
    else
    echo
    echo -e "\033[31mNo match found!\033[0m"
    echo "Either the spelling is incorrect or the contact does not exist."
    echo
    search_fn_1
  fi
