clear
tput cup 0 35
echo -e "\033[36m***********\033[0m"
tput cup 1 35
echo -e "\033[36m* 2 0 0 5 *\033[0m"
tput cup 2 35
echo -e "\033[36m***********\033[0m"
echo
echo
echo -e "\033[33m           January                  February                   March\033[0m"
echo -e "\033[33m    --------------------      --------------------      --------------------\033[0m"
echo -e "\033[32m    Su Mo Tu We Th Fr Sa      Su Mo Tu We Th Fr Sa      Su Mo Tu We Th Fr Sa\033[0m"
echo -e "                       1             1  2  3  4  5             1  2  3  4  5"
echo -e "     \033[31m2\033[0m  3  4  5  6  7  8       \033[31m6\033[0m  7  8  9 10 11 12       \033[31m6\033[0m  7  \033[41m8\033[0m  9 10 11 12"
echo -e "     \033[31m9\033[0m 10 11 12 13 14 15      \033[31m13\033[0m 14 15 16 17 18 19      \033[31m13\033[0m 14 15 16 17 18 19"
echo -e "    \033[31m16\033[0m 17 18 19 20 \033[41m21\033[0m 22      \033[41m20\033[0m 21 22 23 24 25 26      \033[31m20\033[0m 21 22 23 24 \033[41m25\033[0m \033[41m26\033[0m"
echo -e "    \033[31m23\033[0m 24 25 \033[41m26\033[0m 27 28 29      \033[31m27\033[0m 28                     \033[31m27\033[0m 28 29 30 31      "
echo -e "    \033[31m30\033[0m 31"
echo -e "\033[33m    --------------------      --------------------      --------------------\033[0m"
echo
echo -e "    \033[31m21 Jan\033[0m - \033[35mBakra Eid\033[0m        \033[31m20 Feb\033[0m - \033[35mMoharram\033[0m          \033[31m8 Mar\033[0m - \033[35mMaha Shivratri\033[0m"
echo -e "    \033[31m26 Jan\033[0m - \033[35mRepublic Day\033[0m                               \033[31m25 Mar\033[0m - \033[35mGood Friday\033[0m"
echo -e "                                                        \033[31m26 Mar\033[0m - \033[35mHoli\033[0m"
echo
echo
echo
echo
echo
echo -e "Press any key to continue...\c"
read -n 1
clear
tput cup 0 35
echo -e "\033[36m***********\033[0m"
tput cup 1 35
echo -e "\033[36m* 2 0 0 5 *\033[0m"
tput cup 2 35
echo -e "\033[36m***********\033[0m"
echo
echo
echo -e "\033[33m            April                      May                      June\033[0m"
echo -e "\033[33m    --------------------      --------------------      --------------------\033[0m"
echo -e "\033[32m    Su Mo Tu We Th Fr Sa      Su Mo Tu We Th Fr Sa      Su Mo Tu We Th Fr Sa\033[0m"
echo -e "                    1  2       \033[41m1\033[0m  2  3  4  5  6  7                1  2  3  4"
echo -e "     \033[31m3\033[0m  4\033[0m  5  6  7  8  \033[41m9\033[0m       \033[31m8\033[0m  9 10 11 12 13 14       \033[31m5\033[0m  6  7  8  9 10 11"
echo -e "    \033[31m10\033[0m 11 12 13 \033[41m14\033[0m 15 16      \033[31m15\033[0m 16 17 18 19 20 21      \033[31m12\033[0m 13 14 15 16 17 18"
echo -e "    \033[31m17\033[0m \033[41m18\033[0m 19 20 21 \033[41m22\033[0m 23      \033[31m22\033[0m \033[41m23\033[0m 24 25 26 27 28      \033[31m19\033[0m 20 21 22 23 24 25"
echo -e "    \033[31m24\033[0m 25 26 27 28 29 30      \033[31m29\033[0m 30 31                  \033[31m26\033[0m 27 28 29 30"
echo -e "\033[33m    --------------------      --------------------      --------------------\033[0m"
echo
echo -e "    \033[31m 9 Apr\033[0m - \033[35mGudi Padwa\033[0m       \033[31m 1 May\033[0m - \033[35mMaharashtra Day\033[0m"
echo -e "    \033[31m14 Apr\033[0m - \033[35mAmbedkar Jayanti\033[0m \033[31m23 May\033[0m - \033[35mBuddh Purnima\033[0m"
echo -e "    \033[31m18 Apr\033[0m - \033[35mRam Navmi\033[0m"
echo -e "    \033[31m22 Apr\033[0m - \033[35mEid-E-Milad\033[0m"
echo -e "             \033[35mMahavir Jayanti\033[0m"
echo
echo
echo
echo
echo -e "Press any key to continue...\c"
read -n 1
clear
tput cup 0 35
echo -e "\033[36m***********\033[0m"
tput cup 1 35
echo -e "\033[36m* 2 0 0 5 *\033[0m"
tput cup 2 35
echo -e "\033[36m***********\033[0m"
echo
echo
echo -e "\033[33m            July                     August                   September\033[0m"
echo -e "\033[33m    --------------------      --------------------      --------------------\033[0m"
echo -e "\033[32m    Su Mo Tu We Th Fr Sa      Su Mo Tu We Th Fr Sa      Su Mo Tu We Th Fr Sa\033[0m"
echo -e "                    1  2          1  2  3  4  5  6                   1  2  3"
echo -e "     \033[31m3\033[0m  4  5  6  7  8  9       \033[31m7\033[0m  8  9 10 11 12 13       \033[31m4\033[0m  5  6  \033[41m7\033[0m  8  9 10"
echo -e "    \033[31m10\033[0m 11 12 13 14 15 16      \033[31m14\033[0m \033[41m15\033[0m 16 17 18 19 \033[41m20\033[0m      \033[31m11\033[0m 12 13 14 15 16 17"
echo -e "    \033[31m17\033[0m 18 19 20 21 22 23      \033[31m21\033[0m 22 23 24 25 26 27      \033[31m18\033[0m 19 20 21 22 23 24"
echo -e "    \033[31m24\033[0m 25 26 27 28 29 30      \033[31m28\033[0m 29 30 31               \033[31m25\033[0m 26 27 28 29 30   "
echo -e "    \033[31m31\033[0m"
echo -e "\033[33m    --------------------      --------------------      --------------------\033[0m"
echo
echo -e "                              \033[31m15 Aug\033[0m - \033[35mIndependence Day\033[0m  \033[31m7 Sep\033[0m - \033[35mGanesh\033[0m"
echo -e "                              \033[31m20 Aug\033[0m - \033[35mParsi New Year\033[0m            \033[35mChaturthi\033[0m"
echo
echo
echo
echo
echo
echo
echo -e "Press any key to continue...\c"
read -n 1
clear
tput cup 0 35
echo -e "\033[36m***********\033[0m"
tput cup 1 35
echo -e "\033[36m* 2 0 0 5 *\033[0m"
tput cup 2 35
echo -e "\033[36m***********\033[0m"
echo
echo
echo -e "\033[33m           October                  November                  December\033[0m"
echo -e "\033[33m    --------------------      --------------------      --------------------\033[0m"
echo -e "\033[32m    Su Mo Tu We Th Fr Sa      Su Mo Tu We Th Fr Sa      Su Mo Tu We Th Fr Sa\033[0m"
echo -e "                       1             \033[41m1\033[0m  2  \033[41m3\033[0m  \033[41m4\033[0m  5                   1  2  3"
echo -e "     \033[41m2\033[0m  3  4  5  6  7  8       \033[31m6\033[0m  7  8  9 10 11 12       \033[31m4\033[0m  5  6  7  8  9 10"
echo -e "     \033[31m9\033[0m 10 11 \033[41m12\033[0m 13 14 15      \033[31m13\033[0m 14 \033[41m15\033[0m 16 17 18 19      \033[31m11\033[0m 12 13 14 15 16 17"
echo -e "    \033[31m16\033[0m 17 18 19 20 21 22      \033[31m20\033[0m 21 22 23 24 25 26      \033[31m18\033[0m 19 20 21 22 23 24"
echo -e "    \033[31m23\033[0m 24 25 26 27 28 29      \033[31m27\033[0m 28 29 30               \033[41m25\033[0m 26 27 28 29 30 31"
echo -e "    \033[31m30\033[0m 31"
echo -e "\033[33m    --------------------      --------------------      --------------------\033[0m"
echo
echo -e "    \033[31m 2 Oct\033[0m - \033[35mGandhi Jayanti\033[0m   \033[31m 1 Nov\033[0m - \033[35mDiwali\033[0m           \033[31m25 Dec\033[0m - \033[35mChristmas Day\033[0m"
echo -e "    \033[31m12 Oct\033[0m - \033[35mDasera\033[0m           \033[31m 3 Nov\033[0m - \033[35mBhau Beej\033[0m"
echo -e "                              \033[31m 4 Nov\033[0m - \033[35mRamzan Eid\033[0m"
echo -e "                              \033[31m15 Nov\033[0m - \033[35mGuru Nanak Jayanti\033[0m"
echo
echo
echo
echo
echo -e "Press any key to exit...\c"
read -n 1
clear
