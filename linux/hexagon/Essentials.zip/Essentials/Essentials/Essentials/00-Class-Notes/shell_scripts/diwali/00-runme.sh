clear
echo
echo
echo
echo
echo
echo
echo
echo
echo
echo
echo
echo
echo
echo
echo
echo
echo
echo
echo "                                     /^\ "
echo "                                     | |" 
echo "                                     |_|"
echo "                                      |\`*"
echo "                                      |"
echo
echo -e "Press any key to ignite the rocket\c"
read -n 1
. 01.sh
