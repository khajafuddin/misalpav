clear
echo
echo
echo
echo
echo
echo
echo
echo
echo
echo
echo
echo
echo
echo "                                     /^\ "
echo "                                     | |" 
echo "                                     |_|"
echo "                                      |\`*"
echo "                                      |"
echo
echo
echo
echo
echo
echo
echo
sleep 0.1
. 06.sh
