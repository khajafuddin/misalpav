#!/bin/bash
echo "Enter two numbers to find even numbers between them?"
read num1 num2
while [ $num1 -le $num2 ]
  do
    rem=`expr $num1 % 2`
    [ $rem -eq 0 ] && echo -n "$num1 "
    num1=`expr $num1 + 1`
  done
echo
