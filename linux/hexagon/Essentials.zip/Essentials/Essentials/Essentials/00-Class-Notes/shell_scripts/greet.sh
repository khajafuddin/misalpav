#!/bin/bash
clear
time=`date +%T | cut -d: -f1`
case $time in
     04|05|06|07|08|09|10|11)
       echo Good Morning! Mr. $USER, Have a nice day!
       ;;
     12|13|14|15)
       echo Good Afternoon! Mr. $USER, Have a nice day!
       ;;
     16|17|18|19)
       echo Good Evening! Mr. $USER, Have a nice day!
       ;;
     20|21|22|23|00|01|02|03)
       echo Good Night! Mr. $USER, Have a nice day!
       ;;
esac
