clear
echo Hello! I am Muzaffar.
echo What is your name?
echo -e "Please type your \033[5m\033[31mNAME\033[0m and press ENTER."
read name
echo Hi! $name, nice to meet you.
echo $name, What is your age?
echo -e "Please type your \033[5m\033[31mAGE\033[0m and press ENTER."
read age
if [ "$age" = "23" ]
then
echo Oh! $name I too am 23 years old.
elif [ "$age" -gt "23" ]
then
echo Oh! $name you are `expr $age - 23` years older to me, I am 23 years old.
elif [ "$age" -lt "23" ]
then
echo Oh! $name you are `expr 23 - $age` years younger to me, I am 23 years old.
fi
