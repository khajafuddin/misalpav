echo -n Loading file, please wait
sleep 1
echo -n .
sleep 1
echo -n .
sleep 1
echo -n .
sleep 1
echo -n .
sleep 1
echo -n .
sleep 1
echo -n .
sleep 1
echo -n .
echo
echo File corrupt! Aborting process.
