dialog --backtitle "Welcome to server.microtech.com" --yesno "Address Book" 5 25
if [ $? = 1 ]
then
echo -n Aborting application. Please wait
sleep 1
echo -n .
sleep 1
echo -n .
sleep 1
echo -n .
sleep 1
echo
clear
exit
fi
