echo -e "Enter the daemon's name: \c"
read DAEMON
if [ -z `pgrep $DAEMON` 2> /dev/null ]
then
echo "$DAEMON is not running"
else
echo
echo "$DAEMON is running"
echo
ps -el | grep -i $DAEMON
fi
