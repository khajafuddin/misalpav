#!/bin/bash
echo -e "Enter a number to view it's square: \c"
read NUMBER
echo -e "Square of $NUMBER is \033[32m`expr $NUMBER \* $NUMBER`\033[0m"
