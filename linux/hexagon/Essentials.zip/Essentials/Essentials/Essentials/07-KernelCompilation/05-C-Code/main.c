int main()
{
	printit();
	printf("\n");
}
