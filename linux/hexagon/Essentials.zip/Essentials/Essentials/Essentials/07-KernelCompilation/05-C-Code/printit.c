#include<stdio.h>
void printit()
{
	printf("Hello, world\nHow r u");
}
