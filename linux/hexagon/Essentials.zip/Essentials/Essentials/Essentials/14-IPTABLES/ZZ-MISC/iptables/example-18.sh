ipchains -P input    ACCEPT
ipchains -P output   ACCEPT
ipchains -P forward  ACCEPT
ipchains -A input -s 0.0 -d 0/0 -i lo                -j ACCEPT
ipchains -A input -p tcp -s 0/0 -d 0/0  0:1023    -y -j REJECT
ipchains -A input -p udp -s 0/0 -d 0/0  0:1023       -j REJECT
ipchains -A input -p tcp -s 0/0 -d 0/0  2049      -y -j REJECT
ipchains -A input -p udp -s 0/0 -d 0/0  2049         -j REJECT
ipchains -A input -p tcp -s 0/0 -d 0/0  6000:6009 -y -j REJECT
ipchains -A input -p tcp -s 0/0 -d 0/0  7100      -y -j REJECT
