# Use this file alongwith sendmail-3.mc
# 29/5/03

# For Q-1
adduser fooroot 
adduser amit 
adduser abdul 


# For Q-2
adduser dc1

# For Q-3
adduser muser1 
adduser muser2 
adduser muser3 
