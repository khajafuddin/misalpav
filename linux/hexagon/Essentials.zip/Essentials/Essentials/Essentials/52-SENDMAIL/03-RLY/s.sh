sync;sync;sync

sendmail -bi

# UnComment required relevant program

# m4 /root/SENDMAIL/02-DF/sendmail-02-01-absmin.mc > /etc/mail/sendmail.cf 

# m4 /root/SENDMAIL/02-DF/sendmail-02-01.mc > /etc/mail/sendmail.cf 

# m4 /root/SENDMAIL/02-DF/sendmail-02-02.mc > /etc/mail/sendmail.cf

# m4 /root/SENDMAIL/02-DF/sendmail-02-03.mc > /etc/mail/sendmail.cf

# m4 /root/SENDMAIL/02-DF/sendmail-02-04.mc > /etc/mail/sendmail.cf

# m4 /root/SENDMAIL/02-DF/sendmail-02-05.mc > /etc/mail/sendmail.cf

service sendmail restart
