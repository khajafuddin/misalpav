m4 /root/Essentials/SENDMAIL/02-DF/sendmail-02-01-absmin.mc > /etc/mail/sendmail.cf && echo "All OK" || echo "Boom"
sendmail -bi
service sendmail restart
