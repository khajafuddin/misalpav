cp john-1.6.tar.gz /tmp

cd /tmp

tar -zxvf john-1.6.tar.gz

cd john-1.6

cd src

echo Do you have an Athlon [1] or Intel [2]
echo Enter 1 or 2

read typ 

if [ $typ = 2 ]
then
     make linux-x86-any-elf 
else     
     make linux-x86-k6-elf
fi     

cd ../run/

mkdir -p /usr/local/sbin/  > /dev/null 2>&1

umask 077              

cp -d john un* /usr/local/sbin/  > /dev/null 2>&1

mkdir /var/lib/john/ > /dev/null 2>&1

cp *.* mailer /var/lib/john/ > /dev/null 2>&1

cd /var/lib/john/

umask 077

unshadow /etc/passwd /etc/shadow > mypasswords

echo Do you want to crack passwords now ???? 
echo Press CR to continue or ^C to quit
read 

echo Cracking passwords..... Pl wait ...

nice -n -20 john mypasswords    
