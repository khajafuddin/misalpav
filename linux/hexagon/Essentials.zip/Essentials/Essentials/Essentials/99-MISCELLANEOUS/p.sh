clear
echo Pinging ganesh [self] 192.168.0.3 g [eth0]
ping -c 1 g > /dev/null
if [ $? = 0 ]
then
   echo -e "\033[32mSuccess\033[0m"
   #read -p "Press a key"
else 
   echo -e "\033[31mCannot Ping self 192.168.0.2 g [eth0]\033[0m"
   #read -p "Press a key"
fi

echo Pinging shiva 192.168.0.10 s
ping -c 1 s > /dev/null 2>&1
if [ $? = 0 ]
then
   echo -e "\033[32mSuccess\033[0m"
   #read -p "Press a key"
else 
   echo -e "\033[31mCannot Ping shiva 192.168.0.10\033[0m" 
   #read -p "Press a key"
fi

echo Pinging gw 192.168.1.1 gw [eth1]
ping -c 1 gw > /dev/null
if [ $? = 0 ]
then
   echo -e "\033[32mSuccess\033[0m"
   #read -p "Press a key"
else 
   echo -e "\033[31mCannot Ping gw 192.168.1.2 [eth1]\033[0m" 
   #read -p "Press a key"
fi

echo Pinging dns 192.168.1.1 
ping -c 1 dns > /dev/null
if [ $? = 0 ]
then
   echo -e "\033[32mSuccess\033[0m"
   #read -p "Press a key"
else 
   echo -e "\033[31mCannot Ping dns 192.168.1.1 dns\033[0m" 
   #read -p "Press a key"
fi

echo Pinging yahoo.com
ping -c 1 yahoo.com > /dev/null
if [ $? = 0 ]
then
   echo -e "\033[32mSuccess\033[0m"
   #read -p "Press a key"
else 
   echo -e "\033[31mCannot Ping yahoo.com\033[0m"
   #read -p "Press a key"
fi
